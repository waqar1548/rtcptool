﻿using FuzzyLogicInterface.Models;
using FuzzyLogicInterface.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace FuzzyLogicInterface.Controllers
{
    public class InputController : Controller
    {
        private readonly FuzzyContext db;
        public float lowStart = 0.0f;
        public float lowEnd = 0.33f;
        public float midStart = 0.34f;
        public float midEnd = 0.66f;
        public float hiStart = 0.67f;
        public float hiEnd = 1.0f;

        public InputController(FuzzyContext db)
        {
            this.db = db;

        }

        [HttpGet]
        public IActionResult ModuleRecordInput()
        {
            return View();
        }

        [HttpPost]

        public IActionResult ModuleRecordInput(ModuleRecord mr)
        {
            if (ModelState.IsValid)
            {


                ModuleRecord obj = new ModuleRecord();
                obj.ModuleCriticality = mr.ModuleCriticality;
                obj.ModuleFaultCoverage = mr.ModuleFaultCoverage;
                obj.ModuleCodeCoverage = mr.ModuleCodeCoverage; 

                TempData["ModuleCriticality"] = mr.ModuleCriticality;
                TempData["ModuleFaultCoverage"] = mr.ModuleFaultCoverage;

                obj.StartSession = DateTime.Now;

        
                db.ModulesData.Add(obj);
                db.SaveChanges();
               
            }

            return RedirectToAction("TestRecordInput", "Input");
        }

        [HttpGet]
        public IActionResult TestRecordInput()
        {
            return View();
        }

        [HttpPost]
        public IActionResult TestRecordInput(TestRecord tr)

       {
            if (ModelState.IsValid)
            {
                TestRecord obj = new TestRecord();

                tr.ModuleCREntered = db.ModulesData.OrderByDescending(p => p.Id).FirstOrDefault().ModuleCriticality;

                tr.ModuleFCEntered = db.ModulesData.OrderByDescending(p => p.Id).FirstOrDefault().ModuleFaultCoverage;
                tr.ModuleCCEntered = db.ModulesData.OrderByDescending(p => p.Id).FirstOrDefault().ModuleCodeCoverage;

                TempData["ModuleCriticality"] = tr.ModuleCREntered;

                TempData["ModuleFaultCoverage"] = tr.ModuleFCEntered;

                TempData["ModuleCodeCoverage"] = tr.ModuleCCEntered;


                obj.TestType  = tr.TestType;

                obj.ModuleCREntered = tr.ModuleCREntered;

                obj.ModuleFCEntered = tr.ModuleFCEntered;
                obj.ModuleCCEntered = tr.ModuleCCEntered;

                tr.CriticalityOfRequirement = (int)Math.Floor(tr.CriticalityOfRequirement);
                obj.CriticalityOfRequirement = tr.CriticalityOfRequirement;

                tr.FaultCoverage = (int)Math.Floor(tr.FaultCoverage);
                obj.FaultCoverage = tr.FaultCoverage;

                obj.CodeCoverage = tr.CodeCoverage;


                tr.dbEntry = DateTime.Now;
                obj.dbEntry = tr.dbEntry;

               float CRpriority = (float)Math.Round((tr.CriticalityOfRequirement / tr.ModuleCREntered) * (0.5),2);
               float FCpriority = (float)Math.Round((tr.FaultCoverage / tr.ModuleFCEntered) * (0.5), 2);

                // float CCpriority = (tr.TestCodeLines / tr.ModuleCodeLinesEntered) ;
                //float FCpriority = (tr.FaultCoverage / tr.ModuleFCEntered) ;


                // tr.PriorityValue = (float)Math.Round((CCpriority *0.5),2) + (float)Math.Round((FCpriority *0.5),2);
                tr.PriorityValue = (float)Math.Round((CRpriority + FCpriority),2);
                //tr.PriorityValue = (float)Math.Round(tr.PriorityValue, 2);
                obj.PriorityValue = tr.PriorityValue;


                if (CRpriority > 0.5)
                {
                    ViewData["Warning1"] = "Test Case criticality should be less than module criticality.";

                    return View();
                }

               else if (FCpriority > 0.5)
                {
                    ViewData["Warning2"] = "Test Case fault coverage should be less than module fault coverage.";

                    return View();
                }
                else if (tr.PriorityValue >= lowStart && tr.PriorityValue <= lowEnd)
                {
                    obj.Priority = "Low";
                }
                else if (tr.PriorityValue >= midStart && tr.PriorityValue <= midEnd)
                {
                    obj.Priority = "Medium";
                }
                else if (tr.PriorityValue >= hiStart && tr.PriorityValue <= hiEnd)
                {
                    obj.Priority = "High";
                }
              
                db.TestsData.Add(obj);
                db.SaveChanges();
                ModelState.Clear();

                ViewData["Message"] = "Test Record Entered Successfully";
        }
            else
            {
                ModelState.Clear();
            }
            return View();

}

       


        [HttpGet]
        public IActionResult SortOutput()
        {

            //TestRecord tr = new TestRecord();
            //tr.dbEntry = db.ModulesData.OrderByDescending(p => p.Id).FirstOrDefault().StartSession;
            var startTime = db.ModulesData.OrderByDescending(p => p.Id).FirstOrDefault().StartSession;
            var listdata = db.TestsData.Where(x => x.dbEntry > startTime).ToList();

        
            return View(listdata.ToList());
        }
    }
}
