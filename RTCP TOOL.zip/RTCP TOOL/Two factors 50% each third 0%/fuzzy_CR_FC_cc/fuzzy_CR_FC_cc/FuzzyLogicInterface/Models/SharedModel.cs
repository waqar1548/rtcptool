﻿using System.ComponentModel.DataAnnotations;

namespace FuzzyLogicInterface.Models
{
    public class SharedModel
    {
          public int Id   { get; set; }
    }
}
