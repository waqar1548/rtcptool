﻿//using ExpressiveAnnotations.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace FuzzyLogicInterface.Models
{
    public class TestRecord : SharedModel
    {
       [Required(ErrorMessage = "Specify test type or test number")]

        public string TestType { get; set; }

        [ScaffoldColumn(false)]
        public int ModuleCREntered { get; set; }


        [Required(ErrorMessage = "Enter criticality of requirement")]
        public float CriticalityOfRequirement { get; set; }

        [ScaffoldColumn(false)]
        public int ModuleFCEntered { get; set; }

        [Required(ErrorMessage = "Enter fault coverage of test case")]
        public float FaultCoverage { get; set; }

        [ScaffoldColumn(false)]
        public int ModuleCCEntered { get; set; }

        [Required(ErrorMessage = "Enter code coverage of test case")]
        public float CodeCoverage { get; set; }


        [ScaffoldColumn(false)]
        public float PriorityValue { get; set; }

        [ScaffoldColumn(false)]
        public string Priority { get; set; }

        [ScaffoldColumn(false)]
        public DateTime dbEntry { get; set; }



    }
}
