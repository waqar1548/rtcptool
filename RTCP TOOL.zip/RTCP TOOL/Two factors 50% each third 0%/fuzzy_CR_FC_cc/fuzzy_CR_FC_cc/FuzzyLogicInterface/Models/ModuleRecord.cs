﻿using NuGet.Protocol.Plugins;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FuzzyLogicInterface.Models
{
    public class ModuleRecord : SharedModel
    {


        [Required(ErrorMessage = "Enter criticality of requirement your module have")]
        public int ModuleCriticality { get; set; }


        [Required(ErrorMessage = "Enter fault coverage of your module")]
        public int ModuleFaultCoverage { get; set; }


        [Required(ErrorMessage = "Enter code coverage of your module")]
        public int ModuleCodeCoverage { get; set; }

        [ScaffoldColumn(false)]
        public DateTime StartSession { get; set; }

     
    }
}
